# Local AI Assistant Stack with MCP (AnythingLLM + LangChain + Penpot MCP)

This stack provides:
- **AnythingLLM** (JAN) for local LLM processing
- **LangChain agent** HTTP API for orchestration
- **DuckDuckGo web search** integrated in agent
- **Penpot MCP integration** (proxy to Penpot design files)
- **LangChain agent MCP server** for VSCode/Cursor/Claude Desktop integration

## Usage

### Start full stack
docker compose -f docker-compose.yml up --build -d

### Start lightweight stack
docker compose -f docker-compose.no-penpot.yml up --build -d

### Agent HTTP API
POST http://localhost:5000/run
- `prompt`: user prompt
- `use_web`: true/false
- `use_penpot`: true/false
- `penpot_action`: MCP action
- `penpot_params`: action parameters

### Example: web search
POST /run
{
  "prompt": "Summarize AI news today",
  "use_web": true
}

### Example: Penpot MCP
POST /run
{
  "prompt": "Summarize design files",
  "use_penpot": true,
  "penpot_action": "list-files"
}

### Run MCP server (VSCode/Cursor/Claude)
docker compose exec langchain-agent python langchain-agent/mcp_server.py

- Tools available in MCP clients:
  - `duckduckgo` → search queries
  - `penpot` → proxy actions to Penpot MCP

Configure MCP client in VSCode/Cursor to point to this server for full integrated browsing + Penpot support.
