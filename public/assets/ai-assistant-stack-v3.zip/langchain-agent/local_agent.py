# Minimal LangChain-like local agent scaffold with DuckDuckGo + Penpot MCP integration.

import os
import json
from flask import Flask, request, jsonify
import requests
from duckduckgo_search import ddg
from dotenv import load_dotenv

load_dotenv()

LLM_API_URL = os.environ.get("LLM_API_URL", "http://localhost:8080")
LLM_API_KEY = os.environ.get("LLM_API_KEY", "")
LLM_MODEL = os.environ.get("LLM_MODEL", "gpt-4o")

PENPOT_MCP_URL = os.environ.get("PENPOT_MCP_URL", "http://penpot-mcp:5000")

app = Flask(__name__)

def query_local_llm(prompt, system=None, max_tokens=512):
    headers = {}
    if LLM_API_KEY:
        headers['Authorization'] = f"Bearer {LLM_API_KEY}"

    chat_url = f"{LLM_API_URL.rstrip('/')}/v1/chat/completions"
    payload = {
        "model": LLM_MODEL,
        "messages": [
            {"role": "system", "content": system or "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
    }
    try:
        r = requests.post(chat_url, json=payload, headers=headers, timeout=30)
        if r.ok:
            data = r.json()
            if 'choices' in data and len(data['choices'])>0:
                return data['choices'][0].get('message', {}).get('content') or data['choices'][0].get('text')
    except Exception as e:
        app.logger.debug(f"Chat endpoint failed: {e}")

    comp_url = f"{LLM_API_URL.rstrip('/')}/v1/completions"
    payload = {
        "model": LLM_MODEL,
        "prompt": prompt,
        "max_tokens": max_tokens,
    }
    r = requests.post(comp_url, json=payload, headers=headers, timeout=30)
    if r.ok:
        data = r.json()
        if 'choices' in data and len(data['choices'])>0:
            return data['choices'][0].get('text')
    r.raise_for_status()

def web_search(query, max_results=5):
    try:
        results = ddg(query, max_results=max_results)
        return results or []
    except Exception as e:
        app.logger.error(f"Web search failed: {e}")
        return []

def call_penpot_mcp(action, params=None):
    """Send a request to the Penpot MCP server."""
    try:
        url = f"{PENPOT_MCP_URL.rstrip('/')}/mcp"
        payload = {"action": action, "params": params or {}}
        r = requests.post(url, json=payload, timeout=30)
        if r.ok:
            return r.json()
        return {"error": "penpot-mcp error", "status": r.status_code, "body": r.text}
    except Exception as e:
        app.logger.error(f"Penpot MCP call failed: {e}")
        return {"error": str(e)}

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

@app.route('/run', methods=['POST'])
def run_agent():
    payload = request.get_json(force=True, silent=True) or {}
    prompt = payload.get('prompt') or payload.get('query') or ''
    use_web = payload.get('use_web', False)
    use_penpot = payload.get('use_penpot', False)
    system = payload.get('system')

    if not prompt and not use_penpot:
        return jsonify({'error': 'no prompt provided'}), 400

    context = ''
    if use_web:
        q = payload.get('web_query', prompt)
        results = web_search(q, max_results=5)
        snippets = []
        for r in results:
            title = r.get('title') or ''
            snippet = r.get('body') or ''
            href = r.get('href') or ''
            snippets.append(f"- {title}\n  {snippet}\n  {href}")
        context = "\n\nWeb search results:\n" + "\n".join(snippets)

    if use_penpot:
        action = payload.get('penpot_action', 'list-files')
        params = payload.get('penpot_params', {})
        penpot_result = call_penpot_mcp(action, params)
        context += "\n\nPenpot MCP response:\n" + json.dumps(penpot_result, indent=2)

    full_prompt = prompt + ( "\n\n" + context if context else "" )

    try:
        answer = query_local_llm(full_prompt, system=system)
    except Exception as e:
        return jsonify({'error': 'LLM request failed', 'details': str(e)}), 500

    return jsonify({'answer': answer, 'context': context})

if __name__ == '__main__':
    host = os.environ.get('AGENT_HOST', '0.0.0.0')
    port = int(os.environ.get('AGENT_PORT', 5000))
    app.run(host=host, port=port)
