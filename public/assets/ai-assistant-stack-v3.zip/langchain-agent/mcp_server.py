import asyncio
import os
import aiohttp
from modelcontextprotocol.server import Server
from modelcontextprotocol.types import Tool, TextContent, CallToolResult

MCP_SERVER_NAME = "LangChainAgent"
PENPOT_MCP_URL = os.getenv("PENPOT_MCP_URL", "http://penpot-mcp:5000")

server = Server(name=MCP_SERVER_NAME, version="0.1.0")

# DuckDuckGo tool
@server.tool()
async def duckduckgo(query: str) -> CallToolResult:
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://api.duckduckgo.com/?q={query}&format=json") as resp:
            data = await resp.text()
    return CallToolResult(content=[TextContent(text=f"Results: {data}")])

# Penpot tool (proxy to MCP server)
@server.tool()
async def penpot(action: str = "list-files", **params) -> CallToolResult:
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{PENPOT_MCP_URL}/call", json={"action": action, "params": params}) as resp:
            data = await resp.text()
    return CallToolResult(content=[TextContent(text=data)])

async def main():
    async with server.run_stdio_server():
        await asyncio.Future()  # keep running

if __name__ == "__main__":
    asyncio.run(main())
